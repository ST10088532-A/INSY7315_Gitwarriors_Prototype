package com.itanywhere.itaconnect.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.itanywhere.itaconnect.models.Device
import com.itanywhere.itaconnect.theme.StatusResolved

@Composable
fun DeviceCard(device: Device, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val icon = when (device.type) {
                "Laptop" -> Icons.Filled.Laptop
                "Mobile Device" -> Icons.Filled.Phone
                "Printer" -> Icons.Filled.Print
                else -> Icons.Filled.Devices
            }
            Icon(icon, contentDescription = device.type, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(device.name, style = MaterialTheme.typography.titleMedium)
                Text(device.type, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(device.status, color = StatusResolved, style = MaterialTheme.typography.labelSmall)
                Text("Last seen: ${device.lastSeen}", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
