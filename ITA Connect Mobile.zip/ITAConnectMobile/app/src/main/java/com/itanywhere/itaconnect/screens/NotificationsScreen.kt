package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITABottomBar
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.components.NotificationCard
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun NotificationsScreen(navController: NavHostController, viewModel: AppViewModel) {
    Scaffold(
        topBar = {
            ITATopBar(title = "Notifications") {
                TextButton(onClick = { viewModel.markAllNotificationsRead() }) {
                    Text("Mark All as Read", color = androidx.compose.ui.graphics.Color.White)
                }
            }
        },
        bottomBar = { ITABottomBar(navController = navController, current = Routes.NOTIFICATIONS) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(viewModel.notifications) { notification ->
                NotificationCard(notification = notification, onClick = {
                    viewModel.markNotificationRead(notification.id)
                })
            }
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
