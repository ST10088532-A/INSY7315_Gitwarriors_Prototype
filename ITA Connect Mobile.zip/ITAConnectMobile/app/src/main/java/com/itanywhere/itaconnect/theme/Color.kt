package com.itanywhere.itaconnect.theme

import androidx.compose.ui.graphics.Color

// ITA Connect brand palette - navy blue corporate identity
val ITANavy = Color(0xFF0B1F3A)
val ITANavyLight = Color(0xFF16305A)
val ITABlueAccent = Color(0xFF2E7CF6)
val ITABlueAccentLight = Color(0xFFE8F0FE)
val ITABackground = Color(0xFFF4F6FA)
val ITACardWhite = Color(0xFFFFFFFF)
val ITATextPrimary = Color(0xFF101828)
val ITATextSecondary = Color(0xFF667085)

val StatusOpen = Color(0xFF2E7CF6)
val StatusInProgress = Color(0xFFF59E0B)
val StatusPending = Color(0xFF9333EA)
val StatusResolved = Color(0xFF16A34A)

val PriorityLow = Color(0xFF16A34A)
val PriorityMedium = Color(0xFFF59E0B)
val PriorityHigh = Color(0xFFEA580C)
val PriorityCritical = Color(0xFFDC2626)

// Dark theme variants
val ITADarkBackground = Color(0xFF0B1220)
val ITADarkCard = Color(0xFF16213A)
val ITADarkTextPrimary = Color(0xFFF2F4F8)
val ITADarkTextSecondary = Color(0xFFA0A8BD)
