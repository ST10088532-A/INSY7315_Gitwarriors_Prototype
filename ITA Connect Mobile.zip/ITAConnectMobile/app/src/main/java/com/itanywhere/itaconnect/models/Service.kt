package com.itanywhere.itaconnect.models

data class ServiceStatusItem(
    val id: String,
    val name: String,
    val status: String,
    val detail: String
)
