package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITABottomBar
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun ProfileScreen(navController: NavHostController, viewModel: AppViewModel) {
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var infoDialog by remember { mutableStateOf<Pair<String, String>?>(null) }

    Scaffold(
        topBar = { ITATopBar(title = "Profile") },
        bottomBar = { ITABottomBar(navController = navController, current = Routes.PROFILE) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Filled.AccountCircle,
                        contentDescription = "Profile",
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(viewModel.user.name, style = MaterialTheme.typography.titleLarge)
                    Text(viewModel.user.company, style = MaterialTheme.typography.bodyMedium)
                    Text(viewModel.user.email, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Customer Account: ${viewModel.user.accountNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            ProfileMenuItem(Icons.Filled.Person, "Personal Information") {
                infoDialog = "Personal Information" to "${viewModel.user.name}\n${viewModel.user.email}"
            }
            ProfileMenuItem(Icons.Filled.Business, "Company Information") {
                infoDialog = "Company Information" to "${viewModel.user.company}\nAccount: ${viewModel.user.accountNumber}"
            }
            ProfileMenuItem(Icons.Filled.NotificationsActive, "Notification Preferences") {
                navController.navigate(Routes.SETTINGS)
            }
            ProfileMenuItem(Icons.Filled.HelpOutline, "Help & Support") {
                infoDialog = "Help & Support" to "Contact IT Anywhere Service Desk for assistance. This is a prototype screen."
            }
            ProfileMenuItem(Icons.Filled.Info, "About ITA Connect") {
                infoDialog = "About ITA Connect" to "ITA Connect Mobile is a prototype customer portal built to demonstrate the proposed IT Anywhere customer experience."
            }
            ProfileMenuItem(Icons.AutoMirrored.Filled.Logout, "Logout") {
                showLogoutConfirm = true
            }
        }
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Logout") },
            text = { Text("Are you sure you want to log out of this demonstration?") },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutConfirm = false
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0)
                    }
                }) { Text("Logout") }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("Cancel") }
            }
        )
    }

    infoDialog?.let { (title, text) ->
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text("OK") } },
            title = { Text(title) },
            text = { Text(text) }
        )
    }
}

@Composable
private fun ProfileMenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(16.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, contentDescription = null)
        }
    }
}
