package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.theme.StatusResolved
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun DeviceDetailsScreen(navController: NavHostController, viewModel: AppViewModel, deviceId: String) {
    val device = viewModel.getDevice(deviceId)

    Scaffold(
        topBar = { ITATopBar(title = device?.name ?: "Device", onBack = { navController.popBackStack() }) }
    ) { padding ->
        if (device == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Device not found.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(device.name, style = MaterialTheme.typography.titleLarge)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(device.type, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailLine("Status", device.status, StatusResolved)
                    DetailLine("Serial Number", device.serialNumber)
                    DetailLine("Operating System", device.operatingSystem)
                    DetailLine("Assigned User", device.assignedUser)
                    DetailLine("Last Seen", device.lastSeen)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "This is a view-only prototype screen. Customers cannot perform remote wipes, resets, password changes, or other administrative actions from here.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color? = null) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, color = valueColor ?: MaterialTheme.colorScheme.onSurface)
    }
}
