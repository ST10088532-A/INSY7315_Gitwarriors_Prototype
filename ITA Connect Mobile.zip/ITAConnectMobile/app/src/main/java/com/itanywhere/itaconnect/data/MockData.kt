package com.itanywhere.itaconnect.data

import com.itanywhere.itaconnect.models.*

/**
 * Central source of prototype/demo data.
 * NOTE: This is a working PROTOTYPE. Nothing here is connected to any
 * real IT Anywhere system, HaloPSA, Microsoft Graph, or production backend.
 * All data below is fictional demonstration data only.
 */
object MockData {

    val demoUser = User()

    fun initialTickets(): MutableList<Ticket> = mutableListOf(
        Ticket(
            id = "INC-1024",
            subject = "Email not syncing",
            description = "User is unable to receive new emails on their laptop.",
            category = "Email",
            status = TicketStatus.IN_PROGRESS,
            priority = TicketPriority.MEDIUM,
            createdDate = "Today, 08:30",
            lastUpdated = "10 minutes ago",
            activity = mutableListOf(
                ActivityEntry("08:30", "Ticket created by Alex Johnson"),
                ActivityEntry("09:10", "Assigned to IT Support"),
                ActivityEntry("10:15", "Engineer investigating issue"),
                ActivityEntry("10:30", "Ticket updated")
            )
        ),
        Ticket(
            id = "SRV-2045",
            subject = "New user request",
            description = "Request to set up a new starter with standard access.",
            category = "Other",
            status = TicketStatus.PENDING,
            priority = TicketPriority.LOW,
            createdDate = "Today, 09:00",
            lastUpdated = "Today",
            activity = mutableListOf(
                ActivityEntry("09:00", "Ticket created by Alex Johnson"),
                ActivityEntry("09:05", "Awaiting approval")
            )
        ),
        Ticket(
            id = "INC-1018",
            subject = "Printer unavailable",
            description = "Office printer on 2nd floor is offline.",
            category = "Hardware",
            status = TicketStatus.RESOLVED,
            priority = TicketPriority.LOW,
            createdDate = "Yesterday, 14:20",
            lastUpdated = "Yesterday",
            activity = mutableListOf(
                ActivityEntry("14:20", "Ticket created by Alex Johnson"),
                ActivityEntry("15:00", "Engineer dispatched"),
                ActivityEntry("15:40", "Printer reconnected and resolved")
            )
        ),
        Ticket(
            id = "INC-1007",
            subject = "Laptop not connecting to Wi-Fi",
            description = "Laptop drops the wireless connection intermittently.",
            category = "Network",
            status = TicketStatus.RESOLVED,
            priority = TicketPriority.HIGH,
            createdDate = "2 days ago",
            lastUpdated = "2 days ago",
            activity = mutableListOf(
                ActivityEntry("Day -2, 09:00", "Ticket created by Alex Johnson"),
                ActivityEntry("Day -2, 11:00", "Network driver updated remotely"),
                ActivityEntry("Day -2, 11:30", "Confirmed resolved by customer")
            )
        )
    )

    fun initialDevices(): List<Device> = listOf(
        Device(
            id = "DEV-001",
            name = "Dell Latitude 5440",
            type = "Laptop",
            status = "Online",
            serialNumber = "DEMO123456",
            operatingSystem = "Windows 11",
            assignedUser = "Alex Johnson",
            lastSeen = "Today, 10:25"
        ),
        Device(
            id = "DEV-002",
            name = "iPhone 15",
            type = "Mobile Device",
            status = "Online",
            serialNumber = "DEMO987654",
            operatingSystem = "iOS 18",
            assignedUser = "Alex Johnson",
            lastSeen = "Today, 10:40"
        ),
        Device(
            id = "DEV-003",
            name = "HP LaserJet Pro",
            type = "Printer",
            status = "Online",
            serialNumber = "DEMO456789",
            operatingSystem = "Firmware 4.2",
            assignedUser = "ABC Corporation - 2nd Floor",
            lastSeen = "Today, 09:15"
        )
    )

    fun initialNotifications(): MutableList<AppNotification> = mutableListOf(
        AppNotification(
            id = "NOTIF-1",
            title = "Maintenance Notice",
            message = "Planned maintenance is scheduled for Saturday at 18:00.",
            isRead = false,
            timestamp = "Today, 08:00"
        ),
        AppNotification(
            id = "NOTIF-2",
            title = "Ticket Updated",
            message = "INC-1024 has been updated by IT Support.",
            isRead = false,
            timestamp = "10 minutes ago"
        ),
        AppNotification(
            id = "NOTIF-3",
            title = "Ticket Resolved",
            message = "INC-1018 has been marked as resolved.",
            isRead = false,
            timestamp = "Yesterday"
        ),
        AppNotification(
            id = "NOTIF-4",
            title = "Service Alert",
            message = "Microsoft 365 services are currently operational.",
            isRead = true,
            timestamp = "2 days ago"
        )
    )

    fun initialArticles(): List<KnowledgeArticle> = listOf(
        KnowledgeArticle(
            id = "KB-1",
            title = "How to reset your Microsoft 365 password",
            category = "Microsoft 365",
            readingTime = "2 min read",
            content = listOf(
                "Go to portal.office.com and select \"Forgot my password\".",
                "Enter your work email address.",
                "Complete the identity verification steps.",
                "Choose a new password that meets the complexity requirements.",
                "Sign in with your new password."
            )
        ),
        KnowledgeArticle(
            id = "KB-2",
            title = "How to configure email on an iPhone",
            category = "Email",
            readingTime = "3 min read",
            content = listOf(
                "Open Settings on your iPhone.",
                "Select Mail, then Accounts.",
                "Select Add Account and choose Microsoft Exchange.",
                "Enter your work email address and password.",
                "Enable Mail and confirm to finish setup."
            )
        ),
        KnowledgeArticle(
            id = "KB-3",
            title = "How to connect to Wi-Fi",
            category = "Networking",
            readingTime = "1 min read",
            content = listOf(
                "Open your device's Wi-Fi settings.",
                "Select the correct company network from the list.",
                "Enter the network password if prompted.",
                "Wait for the connection to be established.",
                "Contact IT Anywhere if the connection fails."
            )
        ),
        KnowledgeArticle(
            id = "KB-4",
            title = "How to clear browser cache and cookies",
            category = "General",
            readingTime = "2 min read",
            content = listOf(
                "Open your browser.",
                "Open browser settings.",
                "Select Privacy and Security.",
                "Select Clear Browsing Data.",
                "Select Cached Images and Files.",
                "Click Clear Data."
            )
        ),
        KnowledgeArticle(
            id = "KB-5",
            title = "How to troubleshoot a printer",
            category = "Printers",
            readingTime = "3 min read",
            content = listOf(
                "Check that the printer is powered on and connected.",
                "Confirm the printer shows as \"Online\" on your device.",
                "Try printing a test page.",
                "Restart the printer if the test page fails.",
                "Log a ticket with IT Anywhere if the issue continues."
            )
        )
    )

    fun initialServices(): List<ServiceStatusItem> = listOf(
        ServiceStatusItem("SVC-1", "Microsoft 365", "Operational", "All Microsoft 365 services are running normally."),
        ServiceStatusItem("SVC-2", "Email Services", "Operational", "Inbound and outbound mail flow is normal."),
        ServiceStatusItem("SVC-3", "Internet Connectivity", "Operational", "No connectivity issues reported."),
        ServiceStatusItem("SVC-4", "IT Anywhere Service Desk", "Operational", "Service desk is open and responding normally."),
        ServiceStatusItem("SVC-5", "Monitoring Platform", "Operational", "All monitored endpoints reporting normally.")
    )

    val categories = listOf("Email", "Hardware", "Software", "Network", "Microsoft 365", "Other")
    val priorities = listOf(TicketPriority.LOW, TicketPriority.MEDIUM, TicketPriority.HIGH, TicketPriority.CRITICAL)
}
