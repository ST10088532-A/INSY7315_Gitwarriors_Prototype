package com.itanywhere.itaconnect.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.itanywhere.itaconnect.screens.*
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun AppNavHost(navController: NavHostController, viewModel: AppViewModel) {
    NavHost(navController = navController, startDestination = Routes.LOGIN) {

        composable(Routes.LOGIN) {
            LoginScreen(onLoginSuccess = {
                navController.navigate(Routes.DASHBOARD) {
                    popUpTo(Routes.LOGIN) { inclusive = true }
                }
            })
        }

        composable(Routes.DASHBOARD) {
            DashboardScreen(navController = navController, viewModel = viewModel)
        }

        composable(Routes.TICKETS) {
            TicketsScreen(navController = navController, viewModel = viewModel)
        }

        composable(Routes.CREATE_TICKET) {
            CreateTicketScreen(navController = navController, viewModel = viewModel)
        }

        composable(
            route = Routes.TICKET_DETAILS,
            arguments = listOf(navArgument("ticketId") { type = NavType.StringType })
        ) { backStackEntry ->
            val ticketId = backStackEntry.arguments?.getString("ticketId") ?: ""
            TicketDetailsScreen(navController = navController, viewModel = viewModel, ticketId = ticketId)
        }

        composable(Routes.DEVICES) {
            DevicesScreen(navController = navController, viewModel = viewModel)
        }

        composable(
            route = Routes.DEVICE_DETAILS,
            arguments = listOf(navArgument("deviceId") { type = NavType.StringType })
        ) { backStackEntry ->
            val deviceId = backStackEntry.arguments?.getString("deviceId") ?: ""
            DeviceDetailsScreen(navController = navController, viewModel = viewModel, deviceId = deviceId)
        }

        composable(Routes.NOTIFICATIONS) {
            NotificationsScreen(navController = navController, viewModel = viewModel)
        }

        composable(Routes.KNOWLEDGE_BASE) {
            KnowledgeBaseScreen(navController = navController, viewModel = viewModel)
        }

        composable(
            route = Routes.KNOWLEDGE_ARTICLE,
            arguments = listOf(navArgument("articleId") { type = NavType.StringType })
        ) { backStackEntry ->
            val articleId = backStackEntry.arguments?.getString("articleId") ?: ""
            KnowledgeArticleScreen(navController = navController, viewModel = viewModel, articleId = articleId)
        }

        composable(Routes.SERVICE_STATUS) {
            ServiceStatusScreen(navController = navController, viewModel = viewModel)
        }

        composable(
            route = Routes.SERVICE_DETAILS,
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) { backStackEntry ->
            val serviceId = backStackEntry.arguments?.getString("serviceId") ?: ""
            ServiceDetailsScreen(navController = navController, viewModel = viewModel, serviceId = serviceId)
        }

        composable(Routes.PROFILE) {
            ProfileScreen(navController = navController, viewModel = viewModel)
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(navController = navController, viewModel = viewModel)
        }
    }
}
