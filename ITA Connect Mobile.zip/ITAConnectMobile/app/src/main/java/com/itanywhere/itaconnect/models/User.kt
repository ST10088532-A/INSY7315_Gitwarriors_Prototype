package com.itanywhere.itaconnect.models

data class User(
    val name: String = "Alex Johnson",
    val company: String = "ABC Corporation",
    val email: String = "alex.johnson@example.com",
    val accountNumber: String = "ABC-001"
)
