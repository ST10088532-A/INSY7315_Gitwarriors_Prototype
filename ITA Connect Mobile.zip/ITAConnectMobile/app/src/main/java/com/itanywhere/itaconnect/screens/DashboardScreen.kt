package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.*
import com.itanywhere.itaconnect.models.TicketStatus
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun DashboardScreen(navController: NavHostController, viewModel: AppViewModel) {
    val openTickets = viewModel.tickets.filter { it.status != TicketStatus.RESOLVED }
    val unread = viewModel.unreadCount()

    Scaffold(
        bottomBar = { ITABottomBar(navController = navController, current = Routes.DASHBOARD) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ITA CONNECT", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Good morning,", color = Color(0xFFB6C2DA))
                        Text(
                            viewModel.user.name,
                            color = Color.White,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    BadgedBox(badge = {
                        if (unread > 0) Badge { Text(unread.toString()) }
                    }) {
                        IconButton(onClick = { navController.navigate(Routes.NOTIFICATIONS) }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Notifications", tint = Color.White)
                        }
                    }
                }
            }

            LazyColumnDashboardBody(navController, viewModel, openTickets.size)
        }
    }
}

@Composable
private fun LazyColumnDashboardBody(
    navController: NavHostController,
    viewModel: AppViewModel,
    openCount: Int
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate(Routes.TICKETS) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("My Open Tickets", style = MaterialTheme.typography.titleMedium)
                        Text(openCount.toString(), style = MaterialTheme.typography.titleLarge)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    viewModel.tickets.filter { it.status != TicketStatus.RESOLVED }.take(2).forEach { ticket ->
                        Text("${ticket.id} — ${ticket.subject}", style = MaterialTheme.typography.bodyMedium)
                        Text(ticket.status.label, style = MaterialTheme.typography.labelSmall)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    TextButton(
                        onClick = { navController.navigate(Routes.TICKETS) },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("View All Tickets")
                    }
                }
            }
        }

        item {
            Text("Quick Access", style = MaterialTheme.typography.titleMedium)
        }

        item {
            val qaItems = quickAccessItems(navController)
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                qaItems.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowItems.forEach { qa ->
                            Box(modifier = Modifier.weight(1f)) {
                                QuickAccessCard(label = qa.first, icon = qa.second, onClick = qa.third)
                            }
                        }
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            Text("Recent Activity", style = MaterialTheme.typography.titleMedium)
        }

        items(viewModel.tickets.take(3)) { ticket ->
            TicketCard(ticket = ticket, onClick = {
                navController.navigate(Routes.ticketDetails(ticket.id))
            })
        }

        item {
            Text("Notifications", style = MaterialTheme.typography.titleMedium)
        }

        item {
            val latest = viewModel.notifications.firstOrNull()
            if (latest != null) {
                NotificationCard(notification = latest, onClick = {
                    navController.navigate(Routes.NOTIFICATIONS)
                })
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

private fun quickAccessItems(navController: NavHostController): List<Triple<String, androidx.compose.ui.graphics.vector.ImageVector, () -> Unit>> =
    listOf(
        Triple("New Ticket", Icons.Filled.AddCircle) { navController.navigate(Routes.CREATE_TICKET) },
        Triple("Knowledge Base", Icons.Filled.MenuBook) { navController.navigate(Routes.KNOWLEDGE_BASE) },
        Triple("My Devices", Icons.Filled.Devices) { navController.navigate(Routes.DEVICES) },
        Triple("Service Status", Icons.Filled.CheckCircle) { navController.navigate(Routes.SERVICE_STATUS) }
    )
