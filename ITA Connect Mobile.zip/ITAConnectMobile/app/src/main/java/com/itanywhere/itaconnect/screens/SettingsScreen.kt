package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun SettingsScreen(
    navController: NavHostController,
    viewModel: AppViewModel
) {
    // Read the current settings from the ViewModel
    val notificationsEnabled by viewModel.notificationsEnabled
    val darkModeEnabled by viewModel.darkModeEnabled

    // Stores the title and message for the information dialog
    var infoDialog by remember {
        mutableStateOf<Pair<String, String>?>(null)
    }

    Scaffold(
        topBar = {
            ITATopBar(
                title = "Settings",
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {

            // Notifications
            SettingsToggleRow(
                title = "Notifications",
                checked = notificationsEnabled,
                onCheckedChange = { enabled ->
                    viewModel.notificationsEnabled.value = enabled
                }
            )

            // Dark Mode
            SettingsToggleRow(
                title = "Appearance (Dark Mode)",
                checked = darkModeEnabled,
                onCheckedChange = { enabled ->
                    viewModel.darkModeEnabled.value = enabled
                }
            )

            // Help & Support
            SettingsLinkRow(
                title = "Help & Support"
            ) {
                infoDialog =
                    "Help & Support" to
                            "Contact the IT Anywhere Service Desk. This is a prototype screen."
            }

            // Privacy
            SettingsLinkRow(
                title = "Privacy"
            ) {
                infoDialog =
                    "Privacy" to
                            "This prototype uses local demonstration data only. No real customer data is collected."
            }

            // Terms and Conditions
            SettingsLinkRow(
                title = "Terms and Conditions"
            ) {
                infoDialog =
                    "Terms and Conditions" to
                            "This is a prototype application for demonstration purposes only."
            }

            // About
            SettingsLinkRow(
                title = "About"
            ) {
                infoDialog =
                    "About" to
                            "ITA Connect Mobile — working prototype, version 1.0."
            }

            // Logout
            SettingsLinkRow(
                title = "Logout"
            ) {
                navController.navigate(Routes.LOGIN) {
                    popUpTo(0)
                }
            }
        }
    }

    // Information dialog
    infoDialog?.let { (title, text) ->

        AlertDialog(
            onDismissRequest = {
                infoDialog = null
            },

            confirmButton = {
                TextButton(
                    onClick = {
                        infoDialog = null
                    }
                ) {
                    Text("OK")
                }
            },

            title = {
                Text(text = title)
            },

            text = {
                Text(text = text)
            }
        )
    }
}

/**
 * Settings toggle row
 */
@Composable
private fun SettingsToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),

            horizontalArrangement = Arrangement.SpaceBetween,

            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge
            )

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    }
}

/**
 * Settings clickable row
 */
@Composable
private fun SettingsLinkRow(
    title: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable {
                onClick()
            }
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),

            verticalAlignment = Alignment.CenterVertically
        ) {

            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )

            androidx.compose.material3.Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "Open $title"
            )
        }
    }
}