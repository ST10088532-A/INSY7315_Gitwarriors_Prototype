package com.itanywhere.itaconnect.components

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.itanywhere.itaconnect.models.TicketPriority
import com.itanywhere.itaconnect.models.TicketStatus
import com.itanywhere.itaconnect.theme.*

@Composable
fun StatusBadge(status: TicketStatus) {
    val color = when (status) {
        TicketStatus.OPEN -> StatusOpen
        TicketStatus.IN_PROGRESS -> StatusInProgress
        TicketStatus.PENDING -> StatusPending
        TicketStatus.RESOLVED -> StatusResolved
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(20.dp)) {
        Text(
            text = status.label,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            modifier = androidx.compose.ui.Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun PriorityBadge(priority: TicketPriority) {
    val color = when (priority) {
        TicketPriority.LOW -> PriorityLow
        TicketPriority.MEDIUM -> PriorityMedium
        TicketPriority.HIGH -> PriorityHigh
        TicketPriority.CRITICAL -> PriorityCritical
    }
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(20.dp)) {
        Text(
            text = priority.label,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            modifier = androidx.compose.ui.Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun OperationalBadge(status: String) {
    val color = if (status.equals("Operational", ignoreCase = true)) StatusResolved else PriorityHigh
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(20.dp)) {
        Text(
            text = status,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            modifier = androidx.compose.ui.Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
