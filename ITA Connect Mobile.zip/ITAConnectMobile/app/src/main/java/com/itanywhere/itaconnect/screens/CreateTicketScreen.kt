package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.data.MockData
import com.itanywhere.itaconnect.models.TicketPriority
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTicketScreen(navController: NavHostController, viewModel: AppViewModel) {
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(MockData.categories.first()) }
    var priority by remember { mutableStateOf(TicketPriority.MEDIUM) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var priorityExpanded by remember { mutableStateOf(false) }
    var subjectError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }
    var attachmentAdded by remember { mutableStateOf(false) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { ITATopBar(title = "Create New Ticket", onBack = { navController.popBackStack() }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it; subjectError = null },
                label = { Text("Subject") },
                isError = subjectError != null,
                supportingText = { subjectError?.let { Text(it) } },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it; descriptionError = null },
                label = { Text("Description") },
                isError = descriptionError != null,
                supportingText = { descriptionError?.let { Text(it) } },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = it }) {
                OutlinedTextField(
                    value = category,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Category") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                    MockData.categories.forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = {
                            category = option
                            categoryExpanded = false
                        })
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            ExposedDropdownMenuBox(expanded = priorityExpanded, onExpandedChange = { priorityExpanded = it }) {
                OutlinedTextField(
                    value = priority.label,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Priority") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = priorityExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = priorityExpanded, onDismissRequest = { priorityExpanded = false }) {
                    MockData.priorities.forEach { option ->
                        DropdownMenuItem(text = { Text(option.label) }, onClick = {
                            priority = option
                            priorityExpanded = false
                        })
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { attachmentAdded = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.AttachFile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (attachmentAdded) "1 file attached (demo)" else "Add Attachment")
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    var hasError = false
                    if (subject.isBlank()) {
                        subjectError = "Please enter a subject."
                        hasError = true
                    }
                    if (description.isBlank()) {
                        descriptionError = "Please enter a description."
                        hasError = true
                    }
                    if (!hasError) {
                        val newTicket = viewModel.createTicket(subject, description, category, priority)
                        successMessage = "Ticket ${newTicket.id} submitted successfully."
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("Submit Ticket")
            }
        }
    }

    successMessage?.let { message ->
        AlertDialog(
            onDismissRequest = {
                successMessage = null
                navController.popBackStack()
            },
            confirmButton = {
                TextButton(onClick = {
                    successMessage = null
                    navController.popBackStack()
                }) { Text("OK") }
            },
            title = { Text("Success") },
            text = { Text(message) }
        )
    }
}
