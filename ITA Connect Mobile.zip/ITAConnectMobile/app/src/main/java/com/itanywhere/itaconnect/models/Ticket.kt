package com.itanywhere.itaconnect.models

enum class TicketStatus(val label: String) {
    OPEN("Open"),
    IN_PROGRESS("In Progress"),
    PENDING("Pending"),
    RESOLVED("Resolved")
}

enum class TicketPriority(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High"),
    CRITICAL("Critical")
}

data class ActivityEntry(
    val time: String,
    val text: String
)

data class Ticket(
    val id: String,
    val subject: String,
    val description: String,
    val category: String,
    var status: TicketStatus,
    val priority: TicketPriority,
    val createdDate: String,
    var lastUpdated: String,
    val activity: MutableList<ActivityEntry> = mutableListOf()
)
