package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.components.ITABottomBar
import com.itanywhere.itaconnect.components.TicketCard
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

private val filters = listOf("All", "Open", "In Progress", "Pending", "Resolved")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TicketsScreen(navController: NavHostController, viewModel: AppViewModel) {
    val query by viewModel.ticketSearchQuery
    val filter by viewModel.ticketFilter
    val filteredTickets = viewModel.filteredTickets()

    Scaffold(
        topBar = { ITATopBar(title = "My Tickets") },
        bottomBar = { ITABottomBar(navController = navController, current = Routes.TICKETS) },
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate(Routes.CREATE_TICKET) }) {
                Icon(Icons.Filled.Add, contentDescription = "New Ticket")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.ticketSearchQuery.value = it },
                placeholder = { Text("Search tickets...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRowFilters(filter, onSelect = { viewModel.ticketFilter.value = it })

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredTickets.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No tickets found.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(filteredTickets) { ticket ->
                        TicketCard(ticket = ticket, onClick = {
                            navController.navigate(Routes.ticketDetails(ticket.id))
                        })
                    }
                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }
    }
}

@Composable
private fun LazyRowFilters(selected: String, onSelect: (String) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filters) { filterOption ->
            FilterChip(
                selected = selected == filterOption,
                onClick = { onSelect(filterOption) },
                label = { Text(filterOption) }
            )
        }
    }
}
