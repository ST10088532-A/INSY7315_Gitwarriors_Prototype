package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.components.OperationalBadge
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun ServiceDetailsScreen(navController: NavHostController, viewModel: AppViewModel, serviceId: String) {
    val service = viewModel.getService(serviceId)

    Scaffold(
        topBar = { ITATopBar(title = service?.name ?: "Service", onBack = { navController.popBackStack() }) }
    ) { padding ->
        if (service == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Service not found.")
            }
            return@Scaffold
        }
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(service.name, style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            OperationalBadge(service.status)
            Spacer(modifier = Modifier.height(16.dp))
            Text(service.detail, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
