package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.DeviceCard
import com.itanywhere.itaconnect.components.ITABottomBar
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun DevicesScreen(navController: NavHostController, viewModel: AppViewModel) {
    Scaffold(
        topBar = { ITATopBar(title = "My Devices") },
        bottomBar = { ITABottomBar(navController = navController, current = Routes.DEVICES) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(viewModel.devices) { device ->
                DeviceCard(device = device, onClick = {
                    navController.navigate(Routes.deviceDetails(device.id))
                })
            }
            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}
