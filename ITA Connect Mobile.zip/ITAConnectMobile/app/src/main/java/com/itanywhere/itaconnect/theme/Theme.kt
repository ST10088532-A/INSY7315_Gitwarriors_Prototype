package com.itanywhere.itaconnect.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = ITANavy,
    onPrimary = Color.White,
    secondary = ITABlueAccent,
    background = ITABackground,
    surface = ITACardWhite,
    onBackground = ITATextPrimary,
    onSurface = ITATextPrimary
)

private val DarkColors = darkColorScheme(
    primary = ITABlueAccent,
    secondary = ITABlueAccent,
    background = ITADarkBackground,
    surface = ITADarkCard,
    onBackground = ITADarkTextPrimary,
    onSurface = ITADarkTextPrimary
)

@Composable
fun ITAConnectTheme(
    useDarkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (useDarkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = ITATypography,
        content = content
    )
}
