package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.components.PriorityBadge
import com.itanywhere.itaconnect.components.StatusBadge
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun TicketDetailsScreen(navController: NavHostController, viewModel: AppViewModel, ticketId: String) {
    val ticket = viewModel.getTicket(ticketId)
    var comment by remember { mutableStateOf("") }

    Scaffold(
        topBar = { ITATopBar(title = ticketId, onBack = { navController.popBackStack() }) }
    ) { padding ->
        if (ticket == null) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("Ticket not found.")
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(ticket.subject, style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusBadge(ticket.status)
                PriorityBadge(ticket.priority)
            }

            Spacer(modifier = Modifier.height(16.dp))
            DetailRow("Category", ticket.category)
            DetailRow("Created", ticket.createdDate)
            DetailRow("Last Updated", ticket.lastUpdated)

            Spacer(modifier = Modifier.height(16.dp))
            Text("Description", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(ticket.description, style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(20.dp))
            Text("Activity Timeline", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    ticket.activity.forEachIndexed { index, entry ->
                        Row(modifier = Modifier.padding(vertical = 6.dp)) {
                            Text(
                                entry.time,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.width(90.dp)
                            )
                            Text(entry.text, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (index != ticket.activity.lastIndex) {
                            Divider()
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("Add Comment", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = comment,
                onValueChange = { comment = it },
                placeholder = { Text("Type a comment...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = {
                    if (comment.isNotBlank()) {
                        viewModel.addComment(ticketId, comment)
                        comment = ""
                    }
                },
                modifier = Modifier.align(androidx.compose.ui.Alignment.End)
            ) {
                Text("Send Comment")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
