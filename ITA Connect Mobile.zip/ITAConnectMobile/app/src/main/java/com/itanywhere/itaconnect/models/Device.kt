package com.itanywhere.itaconnect.models

data class Device(
    val id: String,
    val name: String,
    val type: String,
    val status: String,
    val serialNumber: String,
    val operatingSystem: String,
    val assignedUser: String,
    val lastSeen: String
)
