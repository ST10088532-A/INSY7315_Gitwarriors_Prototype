package com.itanywhere.itaconnect.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.navigation.Routes

private data class BottomItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomItems = listOf(
    BottomItem(Routes.DASHBOARD, "Home", Icons.Filled.Home),
    BottomItem(Routes.TICKETS, "Tickets", Icons.Filled.ConfirmationNumber),
    BottomItem(Routes.DEVICES, "Devices", Icons.Filled.Devices),
    BottomItem(Routes.NOTIFICATIONS, "Notifications", Icons.Filled.Notifications),
    BottomItem(Routes.PROFILE, "Profile", Icons.Filled.Person)
)

@Composable
fun ITABottomBar(navController: NavHostController, current: String) {
    NavigationBar {
        bottomItems.forEach { item ->
            NavigationBarItem(
                selected = current == item.route,
                onClick = {
                    if (current != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(Routes.DASHBOARD)
                            launchSingleTop = true
                        }
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) }
            )
        }
    }
}
