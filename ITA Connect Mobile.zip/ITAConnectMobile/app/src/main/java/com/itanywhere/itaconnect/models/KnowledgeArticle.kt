package com.itanywhere.itaconnect.models

data class KnowledgeArticle(
    val id: String,
    val title: String,
    val category: String,
    val readingTime: String,
    val content: List<String>,
    var feedbackGiven: Boolean = false
)
