package com.itanywhere.itaconnect.navigation

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val TICKETS = "tickets"
    const val CREATE_TICKET = "create_ticket"
    const val TICKET_DETAILS = "ticket_details/{ticketId}"
    const val DEVICES = "devices"
    const val DEVICE_DETAILS = "device_details/{deviceId}"
    const val NOTIFICATIONS = "notifications"
    const val KNOWLEDGE_BASE = "knowledge_base"
    const val KNOWLEDGE_ARTICLE = "knowledge_article/{articleId}"
    const val SERVICE_STATUS = "service_status"
    const val SERVICE_DETAILS = "service_details/{serviceId}"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"

    fun ticketDetails(id: String) = "ticket_details/$id"
    fun deviceDetails(id: String) = "device_details/$id"
    fun knowledgeArticle(id: String) = "knowledge_article/$id"
    fun serviceDetails(id: String) = "service_details/$id"
}
