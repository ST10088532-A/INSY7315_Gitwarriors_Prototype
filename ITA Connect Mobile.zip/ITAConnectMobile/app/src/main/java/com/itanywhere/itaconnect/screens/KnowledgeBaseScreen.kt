package com.itanywhere.itaconnect.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.itanywhere.itaconnect.components.ITABottomBar
import com.itanywhere.itaconnect.components.ITATopBar
import com.itanywhere.itaconnect.components.KnowledgeArticleCard
import com.itanywhere.itaconnect.data.MockData
import com.itanywhere.itaconnect.navigation.Routes
import com.itanywhere.itaconnect.viewmodel.AppViewModel

@Composable
fun KnowledgeBaseScreen(navController: NavHostController, viewModel: AppViewModel) {
    val query by viewModel.kbSearchQuery
    val results = viewModel.filteredArticles()
    val kbCategories = listOf("Email", "Microsoft 365", "Windows", "Networking", "Printers", "Security", "General")

    Scaffold(
        topBar = { ITATopBar(title = "Knowledge Base") },
        bottomBar = { ITABottomBar(navController = navController, current = Routes.KNOWLEDGE_BASE) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.kbSearchQuery.value = it },
                placeholder = { Text("Search articles...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(kbCategories) { cat ->
                    AssistChip(onClick = { viewModel.kbSearchQuery.value = cat }, label = { Text(cat) })
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (results.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No articles found.")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(results) { article ->
                        KnowledgeArticleCard(article = article, onClick = {
                            navController.navigate(Routes.knowledgeArticle(article.id))
                        })
                    }
                    item { Spacer(modifier = Modifier.height(24.dp)) }
                }
            }
        }
    }
}
