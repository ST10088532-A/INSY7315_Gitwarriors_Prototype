package com.itanywhere.itaconnect.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.lifecycle.ViewModel
import com.itanywhere.itaconnect.data.MockData
import com.itanywhere.itaconnect.models.*

/**
 * Single shared ViewModel holding all in-memory prototype state.
 * There is no persistence and no backend - everything resets when the
 * process restarts. This is intentional for a prototype.
 */
class AppViewModel : ViewModel() {

    val user = MockData.demoUser

    // ---- Tickets ----
    val tickets: SnapshotStateList<Ticket> = MockData.initialTickets().toMutableStateList()

    var ticketSearchQuery = mutableStateOf("")
    var ticketFilter = mutableStateOf("All") // All, Open, In Progress, Pending, Resolved

    fun filteredTickets(): List<Ticket> {
        val query = ticketSearchQuery.value.trim().lowercase()
        return tickets.filter { ticket ->
            val matchesFilter = when (ticketFilter.value) {
                "All" -> true
                "Open" -> ticket.status == TicketStatus.OPEN
                "In Progress" -> ticket.status == TicketStatus.IN_PROGRESS
                "Pending" -> ticket.status == TicketStatus.PENDING
                "Resolved" -> ticket.status == TicketStatus.RESOLVED
                else -> true
            }
            val matchesSearch = query.isEmpty() ||
                ticket.subject.lowercase().contains(query) ||
                ticket.id.lowercase().contains(query) ||
                ticket.category.lowercase().contains(query)
            matchesFilter && matchesSearch
        }
    }

    fun getTicket(id: String): Ticket? = tickets.find { it.id == id }

    private var nextTicketNumber = 1050

    fun createTicket(subject: String, description: String, category: String, priority: TicketPriority): Ticket {
        val id = "INC-$nextTicketNumber"
        nextTicketNumber++
        val newTicket = Ticket(
            id = id,
            subject = subject,
            description = description,
            category = category,
            status = TicketStatus.OPEN,
            priority = priority,
            createdDate = "Just now",
            lastUpdated = "Just now",
            activity = mutableListOf(ActivityEntry("Now", "Ticket created by ${user.name}"))
        )
        tickets.add(0, newTicket)
        addNotification(
            title = "Ticket Created",
            message = "$id has been submitted and is now open."
        )
        return newTicket
    }

    fun addComment(ticketId: String, comment: String) {
        val ticket = getTicket(ticketId) ?: return
        if (comment.isBlank()) return
        ticket.activity.add(ActivityEntry("Now", "${user.name} commented: $comment"))
        ticket.lastUpdated = "Just now"
    }

    // ---- Devices ----
    val devices: List<Device> = MockData.initialDevices()
    fun getDevice(id: String): Device? = devices.find { it.id == id }

    // ---- Notifications ----
    val notifications: SnapshotStateList<AppNotification> = MockData.initialNotifications().toMutableStateList()

    fun unreadCount(): Int = notifications.count { !it.isRead }

    fun markNotificationRead(id: String) {
        notifications.find { it.id == id }?.isRead = true
    }

    fun markAllNotificationsRead() {
        notifications.forEach { it.isRead = true }
    }

    private var notifCounter = 100
    private fun addNotification(title: String, message: String) {
        notifCounter++
        notifications.add(
            0,
            AppNotification(
                id = "NOTIF-$notifCounter",
                title = title,
                message = message,
                isRead = false,
                timestamp = "Just now"
            )
        )
    }

    // ---- Knowledge Base ----
    val articles: SnapshotStateList<KnowledgeArticle> = MockData.initialArticles().toMutableStateList()
    var kbSearchQuery = mutableStateOf("")

    fun filteredArticles(): List<KnowledgeArticle> {
        val query = kbSearchQuery.value.trim().lowercase()
        if (query.isEmpty()) return articles
        return articles.filter {
            it.title.lowercase().contains(query) || it.category.lowercase().contains(query)
        }
    }

    fun getArticle(id: String): KnowledgeArticle? = articles.find { it.id == id }

    fun rateArticle(id: String, helpful: Boolean) {
        getArticle(id)?.feedbackGiven = true
    }

    // ---- Service status ----
    val services: List<ServiceStatusItem> = MockData.initialServices()
    fun getService(id: String): ServiceStatusItem? = services.find { it.id == id }

    // ---- Settings ----
    var notificationsEnabled = mutableStateOf(true)
    var darkModeEnabled = mutableStateOf(false)
}
