package com.itanywhere.itaconnect.models

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    var isRead: Boolean = false,
    val timestamp: String
)
